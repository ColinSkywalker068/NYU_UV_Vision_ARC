BASE_IMAGE=python


# distro release-dependent build options 
source docker/containers/scripts/opencv_version.sh
	
	
# build the container
sudo docker build -t $TAG -f Dockerfile \
		.
